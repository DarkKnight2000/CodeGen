#include<stdio.h>

int main(){
    while(0) printf("Hi\"\t\r\n");
    return 0;
}